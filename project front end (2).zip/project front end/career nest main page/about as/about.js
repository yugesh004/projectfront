// Example: Show an alert when the "Contact Us" email is clicked
document.querySelector('#contact a').addEventListener('click', function() {
    alert("Thank you for reaching out to us!");
});
